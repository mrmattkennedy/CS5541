Date: 02/02/2021

Class: CS5541

Assignment: Number_Demonstration (Module 1)

Author: Matt Kennedy


gcc -std=c99 -Wall -o number_demonstration number_demonstration.c


Warnings: I had a few warnings, but I was supposed to.


Results:
Problem 1: 
Expected: 2.50000000
Result: 2.50000000


Problem 2
Expected: -0.1000000015
Result: -0.1000000015


Problem 3.1
Expected: 0.0000000000
Result: 0.0000000000


Problem 3.2
Expected: 0.3333333333
Result: 0.3333333333


Problem 4.1
Expected: 9999999.3399999999
Result: 9999999.3399999999


Problem 4.2
Expected: 9999999.0000000000
Result: 9999999.0000000000


Problem 5.1
Expected: 900000000
Result: 900000000


Problem 5.2
Expected: 1600000000
Result: 1600000000


Problem 5.3
Expected: -1794967296
Result: -1794967296


Problem 5.4
Expected: -694967296
Result: -694967296

Problem 5.5
Expected: 605032704
Result: 605032704


Problem 6.1
Expected: 100000002004087734272.000000
Result: 100000002004087734272.000000


Problem 6.2
Expected: 100000002004087734272.000000
Result: 100000002004087734272.000000


Problem 6.3
Expected: 103500002601996386304.000000
Result: 103500002601996386304.000000


Problem 6.4
Expected: 100000002004087734272.000000
Result: 100000002004087734272.000000


