Date: 01/13/2021

Class: CS5541

Assignment: Simple_C_Program

Author: Matt Kennedy


gcc -std=c99 -Wall -o simple_c_program simple_c_program.c
